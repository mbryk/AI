#include "square.h"

Square::Square(int pcolor, int xloc, int yloc){
	color = pcolor;
	x = xloc; y = yloc;
	king = false; //INITIALIZED
}